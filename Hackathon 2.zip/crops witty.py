import xlrd as xl
import openpyxl
import pandas as pd
import webbrowser
from matplotlib import pyplot as plt
path='C:\\CropsDataFile.xlsx'
wb=xl.open_workbook(path)
sheet=wb.sheet_by_index(0)
state=[]
district=[]
year=[]
season=[]
crop=[]
area=[]
production=[]
year1=[]
prod1=[]
for i2 in range (2,sheet.nrows):
    state.append(sheet.cell_value(i2,0))
    district.append(sheet.cell_value(i2,1))
    year.append(sheet.cell_value(i2,2))
    season.append(sheet.cell_value(i2,3))
    crop.append(sheet.cell_value(i2,4))
    area.append(sheet.cell_value(i2,5))
    production.append(sheet.cell_value(i2,6))
reqstate=[]
reqdistrict=[]
reqyear=[]
reqseason=[]
reqcrop=[]
reqarea=[]
reqproduction=[]
n=int(input('if you are an admin press 1, user press 2'))
if (n==1):
    n1=input("enter the password")
    if (n1=="admin"):
        n3=int(input('(to see the whole data of crops enter 1) (to see the data in a particular year enter 2) (to add details of a crop enter 3) else enter 4 '))
        while(1):
            if(n3==1):
                d=pd.DataFrame(list(zip(state,district,year,season,crop,area,production)),columns=['STATE','DISTRICT','YEAR','SEASON','CROP','AREA','PRODUCTION'])
                d.to_excel('data.xlsx',header=True)
                webbrowser.open('data.xlsx')
                break
            elif(n3==2):
                patyear=int(input('enter the year to find the data of crops in that particular year '))
                for i1 in range (0,299):
                    if(patyear==year[i1]):
                        reqstate.append(state[i1])
                        reqdistrict.append(district[i1])
                        reqyear.append(year[i1])
                        reqseason.append(season[i1])
                        reqcrop.append(crop[i1].lower())
                        reqarea.append(area[i1])
                        reqproduction.append(production[i1])
                        i1+=1
                    else:
                        i1+=1    
                d=pd.DataFrame(list(zip(reqstate,reqdistrict,reqyear,reqcrop,reqseason,reqarea,reqproduction)),columns=['STATE','DISTRICT','YEAR','CROP','SEASON','AREA','PRODUCTION'])
                d.to_excel('reqdata.xlsx',header=True)
                webbrowser.open('reqdata.xlsx')
                break    
            elif(n3==3):
                name=input('enter the name of state\n')
                dname=input('enter the name of district\n')
                ye=int(input('enter the year\n'))
                sea=input('enter the season\n')
                cro=input('enter the name of crop\n')
                are=float(input('enter the area of crop\n'))
                rpr=float(input('enter the production of crop\n'))
                ln=[name,dname,ye,sea,cro,are,rpr]
                xfile=openpyxl.load_workbook(path)
                ws=xfile.active
                for j in range(1,8):
                    ws.cell(row=sheet.nrows+1,column=j).value=ln[j-1] 
                xfile.save('CropsDataFile1.xlsx')
                webbrowser.open('CropsDataFile1.xlsx')
                break
                    
            else:
                input('enter a correct input')
                break            
    else:   
        input('enter corect password')
elif (n==2):
    n2=int(input('(to see the whole data of crops enter 1) (to see the data in a particular year enter 2)'))
    while(1):
        if(n2==1):
            d=pd.DataFrame(list(zip(state,district,year,season,crop,area,production)),columns=['STATE','DISTRICT','YEAR','SEASON','CROP','AREA','PRODUCTION'])
            d.to_excel('data.xlsx',header=True)
            webbrowser.open('data.xlsx')
            break
        elif(n2==2):
            patyear=int(input('enter the year to find the data of crops in that particular year '))
            for i in range (0,299):
                if(patyear==year[i]):
                    reqstate.append(state[i])
                    reqdistrict.append(district[i])
                    reqyear.append(year[i])
                    reqseason.append(season[i])
                    reqcrop.append(crop[i].lower())
                    reqarea.append(area[i])
                    reqproduction.append(production[i])
                    i=i+1
                else:
                    i=i+1    
                d=pd.DataFrame(list(zip(reqstate,reqdistrict,reqyear,reqcrop,reqseason,reqarea,reqproduction)),columns=['STATE','DISTRICT','YEAR','CROP','SEASON','AREA','PRODUCTION'])
                d.to_excel('reqdata1.xlsx',header=True)
                webbrowser.open('reqdata1.xlsx')
            break
        else:
            int(input('enter a correct input'))   
            





